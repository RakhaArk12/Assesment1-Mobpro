Nama: Rakha Arkan Azzahran

NIM: 6706223078